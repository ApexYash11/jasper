def reflect(state: dict) -> dict:
    return state
